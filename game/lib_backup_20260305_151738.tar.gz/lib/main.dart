import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:mg_common_game/systems/gacha/gacha_pool.dart';
import 'package:mg_common_game/systems/gacha/gacha_manager.dart';
import 'package:mg_common_game/systems/battlepass/battlepass_config.dart';
import 'package:mg_common_game/systems/battlepass/battlepass_manager.dart';
import 'package:flutter/services.dart';
import 'package:get_it/get_it.dart';
import 'package:mg_common_game/core/audio/audio_manager.dart';
import 'package:mg_common_game/core/ui/theme/app_colors.dart';
import 'package:mg_common_game/systems/systems.dart';
import 'core/game_state.dart';
import 'features/dungeon/room.dart';
import 'features/battle/enemy_data.dart';
import 'screens/dungeon_screen.dart';
import 'screens/battle_screen.dart';
import 'screens/shop_screen.dart';
import 'features/events/event_manager.dart';
import 'screens/battlepass_screen.dart';
import 'screens/gacha_screen.dart';
import 'screens/daily_quest_screen.dart';
import 'screens/achievement_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  _setupDI();
  await GetIt.I<AudioManager>().initialize();
  runApp(const TimeSlipApp());
}

void _setupDI() {
  if (!GetIt.I.isRegistered<AudioManager>()) {
    GetIt.I.registerSingleton<AudioManager>(AudioManager());
  // BattlePass 시스템
  GetIt.I.registerSingleton(BattlePassManager());
  // Gacha 시스템
  GetIt.I.registerSingleton(GachaManager());
  // Collection 시스템
  if (!GetIt.I.isRegistered<CollectionManager>()) {
    GetIt.I.registerSingleton(CollectionManager());
    _registerCollections();
  }
  _setupGacha();
  _setupBattlePass();
  }
}

class TimeSlipApp extends StatelessWidget {
  const TimeSlipApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Time Slip Expedition',
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: AppColors.background,
        primaryColor: AppColors.primary,
        colorScheme: ColorScheme.fromSeed(
          seedColor: AppColors.primary,
          brightness: Brightness.dark,
        ),
      ),
      home: const MainGameScreen(),
      routes: {
        '/battlepass': (_) => const BattlePassScreen(),
        '/gacha': (_) => const GachaScreen(),
          '/daily_quest': (_) => const DailyQuestScreen(),
          '/achievement': (_) => const AchievementScreen(),
        },
    );
  }
}

class MainGameScreen extends StatefulWidget {
  const MainGameScreen({super.key});

  @override
  State<MainGameScreen> createState() => _MainGameScreenState();
}

class _MainGameScreenState extends State<MainGameScreen> {
  final GameState _gameState = GameState();
  Room? _currentRoom;
  bool _showShop = false;

  @override
  void initState() {
    super.initState();
    GetIt.I<AudioManager>().playBgm('bgm_dungeon');
    _gameState.startNewRun();
  }

  void _onRoomSelected(Room room) {
    if (room.type == RoomType.battle || room.type == RoomType.boss) {
      setState(() {
        _currentRoom = room;
      });
    } else if (room.type == RoomType.event) {
      _handleEvent(room);
    } else if (room.type == RoomType.shop) {
      setState(() {
        _showShop = true;
      });
    }
  }

  void _handleEvent(Room room) {
    final event = EventManager.generateEvent(_gameState.floor);
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        title: Text(event.title),
        content: Text(event.description),
        actions: [
          TextButton(
            onPressed: () {
              final result = EventManager.resolveEvent(event, _gameState);
              Navigator.pop(ctx);
              _showEventResult(result);
            },
            child: const Text('Interact'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
              _showEventResult('You ignored the ${event.title}.');
            },
            child: const Text('Leave'),
          ),
        ],
      ),
    );
  }

  void _showEventResult(String result) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        content: Text(result),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
              _gameState.nextFloor();
              setState(() {});
            },
            child: const Text('Continue'),
          ),
        ],
      ),
    );
  }

  void _onBattleVictory() {
    setState(() {
      _currentRoom = null;
      _gameState.nextFloor();
    });
  }

  void _onBattleDefeat() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        title: const Text('YOU DIED'),
        content: Text('Floor reached: ${_gameState.floor}'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
              setState(() {
                _currentRoom = null;
                _showShop = false;
                _gameState.startNewRun();
              });
            },
            child: const Text('Time Loop Reset'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_showShop) {
      return ShopScreen(
        gameState: _gameState,
        onLeave: () {
          setState(() {
            _showShop = false;
            _gameState.nextFloor();
          });
        },
      );
    }

    if (_currentRoom != null) {
      return BattleScreen(
        gameState: _gameState,
        room: _currentRoom!,
        onVictory: _onBattleVictory,
        onDefeat: _onBattleDefeat,
      );
    }

    return DungeonScreen(
      key: ValueKey(_gameState.floor),
      gameState: _gameState,
      onRoomSelected: _onRoomSelected,
    );
  }
}


void _setupBattlePass() {
  final bp = GetIt.I<BattlePassManager>();

  final season = BPSeasonBuilder.create28DaySeason(
    id: 'season_1',
    nameKr: '시즌 1',
    startDate: DateTime.now().subtract(const Duration(days: 1)),
    maxLevel: 50,
    expPerLevel: 1000,
  );

  bp.setSeason(season);
  bp.setMissions(
    daily: BPSeasonBuilder.createDefaultDailyMissions(),
    weekly: BPSeasonBuilder.createDefaultWeeklyMissions(),
  );
}


void _setupGacha() {
  final gacha = GetIt.I<GachaManager>();

  gacha.registerPool(GachaPool(
    id: 'standard_pool',
    nameKr: '스탠다드 뽑기',
    items: [
      // N (50%)
      ...List.generate(20, (i) => GachaItem(
        id: 'n_item_$i',
        nameKr: '일반 아이템 $i',
        rarity: GachaRarity.normal,
      )),

      // R (35%)
      ...List.generate(10, (i) => GachaItem(
        id: 'r_item_$i',
        nameKr: '레어 아이템 $i',
        rarity: GachaRarity.rare,
      )),

      // SR (12%)
      ...List.generate(5, (i) => GachaItem(
        id: 'sr_item_$i',
        nameKr: '슈퍼레어 아이템 $i',
        rarity: GachaRarity.superRare,
      )),

      // SSR (2.7%)
      GachaItem(
        id: 'ssr_item_1',
        nameKr: '울트라레어 아이템 1',
        rarity: GachaRarity.ultraRare,
      ),

      // UR (0.3%)
      GachaItem(
        id: 'ur_item_1',
        nameKr: '레전더리 아이템 1',
        rarity: GachaRarity.legendary,
      ),
    ],
  ));
}

void _registerCollections() {
  final collection = GetIt.I<CollectionManager>();

  // Characters 컬렉션
  collection.registerCollection(const Collection(
    id: 'characters',
    name: '캐릭터',
    description: '모든 캐릭터를 수집하세요',
    items: [
      CollectionItem(
        id: 'char_warrior',
        name: '전사',
        description: '강인한 근접 전투 캐릭터',
        rarity: CollectionRarity.common,
      ),
      CollectionItem(
        id: 'char_mage',
        name: '마법사',
        description: '강력한 마법 공격 캐릭터',
        rarity: CollectionRarity.rare,
      ),
      CollectionItem(
        id: 'char_archer',
        name: '궁수',
        description: '원거리 정밀 공격 캐릭터',
        rarity: CollectionRarity.rare,
      ),
      CollectionItem(
        id: 'char_assassin',
        name: '암살자',
        description: '치명적인 은신 공격 캐릭터',
        rarity: CollectionRarity.epic,
      ),
      CollectionItem(
        id: 'char_healer',
        name: '힐러',
        description: '팀을 치유하는 지원 캐릭터',
        rarity: CollectionRarity.legendary,
      ),
    ],
    completionReward: CollectionReward(gold: 10000, gems: 500, experience: 2000),
    milestoneRewards: {
      25: CollectionReward(gold: 1000, gems: 50),
      50: CollectionReward(gold: 3000, gems: 150),
      75: CollectionReward(gold: 5000, gems: 300),
    },
  ));

  // 아이템 해제 콜백 (햅틱 피드백)
  collection.onItemUnlocked = (collectionId, itemId) {
    // SettingsManager가 등록되어 있으면 햅틱 피드백
    debugPrint('Collection item unlocked: $collectionId / $itemId');
  };
}
